/**
 * <pre>
 * Interfaz PilaADT
 * Esta interfaz contiene todas las funcionalidades minimas de las pilas
 * </pre>
 * @author <ul>
 *      <li> Joshua Chaparro Sandoval </li>
 *      <li> Julián Hernández Alás </li>
 *      <li> Robert Derek Bowden Barbero </li>
 *      <li> Rodrigo Demay Carranza </li>
 *      <li> Óscar Larios Mancilla </li>
 * </ul>
 * 
 */
public interface PilaADT <T>{
    
    /**
     * Método que agrega un dato generico al final del arreglo, y en caso de que no haya espacio, expande el arreglo
     * @param dato T Recibe un dato generico
     */
    public void push(T dato);
    
    /**
     * Función que elimina el ultimo dato de la pila
     * @return T Regresa el ultimo dato del arreglo
     */
    public T pop();
    
    /**
     * Función que revisa si el arreglo esta vacio
     * @return <ul>
     * <li> Si el arreglo esta vacio regresa true </li>
     * <li> Si el arreglo no esta vacio regresa false </li>
     * </ul>
     */
    public boolean isEmpty();
    
    /**
     * Función que regresa el ultimo valor del arreglo
     * @return T Regresa el ultimo valor del arreglo
     */
    public T peek();
    
}
